import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  registrationForm!: FormGroup;

  courses: string[] = ['JAVA', 'ANGULAR', 'REACT'];
  banks: string[] = ['SBI', 'ICICI', 'HDFC'];
  paymentModes: string[] = ['Credit Card', 'Debit Card', 'Net Banking'];

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.registrationForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      course: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      bankName: ['', Validators.required],
      paymentMode: ['', Validators.required],
      cardNumber: ['', [Validators.required, Validators.pattern('[0-9]{16}')]],
      cvv: ['', [Validators.required, Validators.pattern('[0-9]{3}')]]
    });
  }

  onSubmit() {
    if (this.registrationForm.valid) {

      console.log(this.registrationForm.value);

      console.log(this.registrationForm.get('firstName')?.value);


    } else {

      this.registrationForm.markAllAsTouched();
    }
  }

}
